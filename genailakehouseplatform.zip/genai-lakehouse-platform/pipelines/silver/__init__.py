"""Silver layer pipelines."""
