"""Gold layer pipelines."""
